﻿using GameLibrary;
using System;

namespace ConsoleUI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Initialize the necessary components
            Rooms rooms = new Rooms();
            Navigation navigation = new Navigation(rooms);

            // Display welcome message and initial room description
            DisplayMenu.WelcomeMessage();
            Console.WriteLine($"You are in the {navigation.CurrentRoom.Name}. {navigation.CurrentRoom.Description}");

            // Main game loop
            while (true)
            {
                Console.WriteLine("\nWhat would you like to do?");
                Console.WriteLine("1. Move");
                Console.WriteLine("2. List Exits");
                Console.WriteLine("3. Quit");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Enter direction (N/S/E/W): ");
                        string direction = Console.ReadLine().ToUpper();
                        navigation.Move(direction);
                        break;
                    case "2":
                        navigation.ListExits();
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }
    }
}
