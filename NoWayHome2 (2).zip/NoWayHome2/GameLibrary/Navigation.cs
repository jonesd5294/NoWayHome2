﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Navigation
    {
        private Rooms rooms;
        public Rooms.Room CurrentRoom { get; private set; }

        public Navigation(Rooms rooms)
        {
            this.rooms = rooms;
            CurrentRoom = rooms.RoomDictionary["Start"];
        }

        public void Move(string direction)
        {
            if (CurrentRoom.Exits.ContainsKey(direction))
            {
                string nextRoomName = CurrentRoom.Exits[direction];
                if (rooms.RoomDictionary.ContainsKey(nextRoomName))
                {
                    CurrentRoom = rooms.RoomDictionary[nextRoomName];
                    Console.WriteLine($"You have entered the {CurrentRoom.Name}. {CurrentRoom.Description}");
                }
                else
                {
                    Console.WriteLine("Error: Room not found.");
                }
            }
            else
            {
                Console.WriteLine("You can't go that way.");
            }
        }

        public void ListExits()
        {
            Console.WriteLine("Available exits:");

            if (CurrentRoom.Exits.Count > 0)
            {
                foreach (var exit in CurrentRoom.Exits)
                {
                    Console.WriteLine(exit.Key);
                }
            }
            else
            {
                Console.WriteLine("No exits available.");
            }
        }
    }

}


