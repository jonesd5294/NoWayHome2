﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Potions
    {
        public List<Item> PotionList { get; private set; }

        public Potions()
        {
            PotionList = new List<Item>
            {
                new Potion("Health Potion", "Restores 20 health points.", 20),
                new Potion("Mana Potion", "Restores 30 mana points.", 30),
                new Potion("Stamina Potion", "Restores 15 stamina points.", 15),
                new Potion("Invisibility Elixir", "Turns you invisible for a short duration.", 0),
                new Potion("Strength Elixir", "Increases your strength for a short duration.", 0)
            };
        }
    }

    public class Potion : Item
    {
        public int RestorationAmount { get; private set; }

        public Potion(string name, string description, int restorationAmount)
            : base(name, description)
        {
            RestorationAmount = restorationAmount;
        }
    }
}
