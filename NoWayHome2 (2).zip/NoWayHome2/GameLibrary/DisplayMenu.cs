﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class DisplayMenu
    {
        public static void WelcomeMessage()
        {
            Console.WriteLine("***********************************************");
            Console.WriteLine("            Welcome to NoWayHome              ");
            Console.WriteLine("***********************************************\n");
            Console.WriteLine("Prepare for an apocalyptic survival experience");
            Console.WriteLine("where you must combat the harsh environment");
            Console.WriteLine("and relentless zombies to find your way home.\n");
            Console.WriteLine("Good luck, survivor!\n");
            Console.WriteLine("***********************************************\n");
        }

        public static int DisplayMainMenu()
        {
            Console.WriteLine("************ Main Menu ************");
            Console.WriteLine("1. New User");
            Console.WriteLine("2. Login");
            Console.WriteLine("3. Exit");
            Console.Write("Enter your choice: ");

            int choice = Convert.ToInt32(Console.ReadLine());

            return choice;
        }
    }


}
