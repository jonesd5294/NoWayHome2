﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Rooms
    {
        public Dictionary<string, Room> RoomDictionary { get; private set; }

        public Rooms()
        {
            Enemies enemies = new Enemies();

            RoomDictionary = new Dictionary<string, Room>
            {
                { "Start", new Room("Start Room", "You are in the starting room.", enemies.EnemyList[0], GetRandomItems(), new Dictionary<string, string> { { "N", "NextRoom" } }) },
                { "NextRoom", new Room("Next Room", "You are in the next room.", enemies.EnemyList[1], GetRandomItems(), new Dictionary<string, string> { { "S", "Start" } }) }
                // Add more rooms with different enemies as needed
            };
        }

        public class Room
        {
            public string Name { get; private set; }
            public string Description { get; private set; }
            public Mob Enemy { get; private set; }
            public List<Item> Items { get; private set; }
            public Dictionary<string, string> Exits { get; private set; }

            public Room(string name, string description, Mob enemy, List<Item> items, Dictionary<string, string> exits)
            {
                Name = name;
                Description = description;
                Enemy = enemy;
                Items = items;
                Exits = exits;
            }
        }

        private List<Item> GetRandomItems()
        {
            Weapons weapons = new Weapons();
            Potions potions = new Potions();

            List<Item> items = new List<Item>
            {
                weapons.WeaponList[0],
                potions.PotionList[0]
            };

            return items;
        }
    }
}

