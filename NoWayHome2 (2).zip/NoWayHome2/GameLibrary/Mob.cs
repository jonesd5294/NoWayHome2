﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Mob
    {
        public string Name { get; private set; }
        public int Health { get; private set; }

        public Mob(string name, int health)
        {
            Name = name;
            Health = health;
        }
    }

    public class Enemies
    {
        public List<Mob> EnemyList { get; private set; }

        public Enemies()
        {
            EnemyList = new List<Mob>
            {
                new Mob("Zombie", 50),
                new Mob("Skeleton", 30),
                new Mob("Werewolf", 70),
                new Mob("Vampire", 60),
                new Mob("Witch", 40)
            };
        }
    }
}
