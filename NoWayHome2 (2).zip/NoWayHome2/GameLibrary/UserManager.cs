﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class UserManager
    {
        private UserDatabase userDatabase;

        public UserManager(UserDatabase database)
        {
            userDatabase = database;
        }

        public bool CreateUser(string username, string password)
        {
            User existingUser = userDatabase.GetUserByUsername(username);

            if (existingUser == null)
            {
                User newUser = new User { Username = username, Password = password };
                userDatabase.AddUser(newUser);
                return true;
            }

            return false;
        }

        public User LogIn(string username, string password)
        {
            User user = userDatabase.GetUserByUsername(username);

            if (user != null && user.Password == password)
            {
                return user;
            }

            return null;
        }
    }
}
