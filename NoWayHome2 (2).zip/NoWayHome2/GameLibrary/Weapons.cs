﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Weapons
    {
        public List<Item> WeaponList { get; private set; }

        public Weapons()
        {
            WeaponList = new List<Item>
            {
                new Weapon("Short Sword", "Short Range", "A basic short sword.", 10),
                new Weapon("Dagger", "Short Range", "A small and sharp dagger.", 8),
                new Weapon("Bow", "Long Range", "A sturdy bow for ranged attacks.", 12),
                new Weapon("Crossbow", "Long Range", "A powerful crossbow.", 15),
                new Weapon("Spear", "Short Range", "A versatile spear for thrusting.", 11)
            };
        }
    }

    public class Weapon : Item
    {
        public string Type { get; private set; }
        public int Damage { get; private set; }

        public Weapon(string name, string type, string description, int damage)
            : base(name, description)
        {
            Type = type;
            Damage = damage;
        }
    }
}
