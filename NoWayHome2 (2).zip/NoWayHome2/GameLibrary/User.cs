﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        // Add other properties as needed (e.g., CurrentHealth, Inventory, etc.).
    }

    public class UserDatabase
    {
        private List<User> users;

        public UserDatabase()
        {
            users = new List<User>();
        }

        public void AddUser(User user)
        {
            users.Add(user);
        }

        public User GetUserByUsername(string username)
        {
            return users.FirstOrDefault(u => u.Username == username);
        }
    }
}
