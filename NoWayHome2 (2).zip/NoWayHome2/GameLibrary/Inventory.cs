﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Inventory
    {
        private List<Item> items;
        public int MaxSlots { get; private set; }

        public Inventory(int maxSlots)
        {
            MaxSlots = maxSlots;
            items = new List<Item>();
        }

        public void AddItem(Item item)
        {
            if (items.Count < MaxSlots)
            {
                items.Add(item);
                Console.WriteLine($"{item.Name} added to inventory.");
            }
            else
            {
                Console.WriteLine("Inventory is full. Cannot add more items.");
            }
        }

        public void RemoveItem(Item item)
        {
            if (items.Contains(item))
            {
                items.Remove(item);
                Console.WriteLine($"{item.Name} removed from inventory.");
            }
            else
            {
                Console.WriteLine($"{item.Name} is not in the inventory.");
            }
        }

        public void ShowInventory()
        {
            Console.WriteLine("Inventory:");

            if (items.Count == 0)
            {
                Console.WriteLine("Empty");
            }
            else
            {
                foreach (var item in items)
                {
                    Console.WriteLine($"{item.Name} - {item.Description}");

                    if (item is Weapon)
                    {
                        Weapon weapon = (Weapon)item;
                        Console.WriteLine($"Type: {weapon.Type}, Damage: {weapon.Damage}");
                    }
                    else if (item is Potion)
                    {
                        Potion potion = (Potion)item;
                        Console.WriteLine($"Restoration Amount: {potion.RestorationAmount}");
                    }
                }
            }
        }
    }
}
