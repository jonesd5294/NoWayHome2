﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Health
    {
        public int CurrentHealth { get; private set; }

        public Health(int initialHealth)
        {
            CurrentHealth = initialHealth;
        }

        public void TakeDamage(int damage)
        {
            CurrentHealth -= damage;

            if (CurrentHealth < 0)
            {
                CurrentHealth = 0;
            }
        }

        public bool IsAlive()
        {
            return CurrentHealth > 0;
        }
    }
}
