﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Combat
    {
        private Random random;

        public Combat()
        {
            random = new Random();
        }

        public int DealDamage()
        {
            return random.Next(1, 15); // Deals random damage between 1 and 15
        }
    }
}
